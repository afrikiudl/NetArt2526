<template>
  <div class="d-flex overflow-auto gap-3 py-2">
    <TiempoDia
      v-for="(item, index) in list"
      :key="index"
      :dayLabel="item.dayLabel"
      :max="item.max"
      :min="item.min"
      :wind="item.wind"
    />
  </div>
</template>

<script>
import TiempoDia from "./TiempoDia.vue"
export default {
  name: "TiempoCarrusel",
  components: { TiempoDia },
  props: { list: Array }
}
</script>
