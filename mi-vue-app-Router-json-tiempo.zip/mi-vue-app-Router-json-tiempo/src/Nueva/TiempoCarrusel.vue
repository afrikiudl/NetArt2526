<template>
  <div class="container py-4">
    <h2 class="fw-bold text-center mb-3">Pronóstico</h2>

    <div class="d-flex gap-3 overflow-auto pb-3">
      <Tiempo1Dia
        v-for="(d, i) in days"
        :key="i"
        :dayLabel="d.day"
        :max="d.max"
        :min="d.min"
        :wind="d.wind"
      />
    </div>

  </div>
</template>

<script>
import Tiempo1Dia from "./Tiempo1Dia.vue"

export default {
  name: "TiempoCarrusel",
  components: { Tiempo1Dia },
  props: { days: Array }
}
</script>

<style scoped>
.d-flex {
  scroll-snap-type: x mandatory;
}
.tiempo-dia {
  scroll-snap-align: center;
}
</style>
