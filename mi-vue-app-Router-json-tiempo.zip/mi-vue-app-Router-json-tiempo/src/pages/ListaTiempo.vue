<template>
    <div class="container py-4">
  
      <h1 class="text-center mb-4">Tiempo (Json externo)</h1>
      <div class="alert alert-primary" role="alert">
        Este ejemplo muestra en GSAP el movimiento de cada información del tiempo. <br/>
        Además, se modifica el color del fondo según la temperatura máxima.
      </div>
  
      <p v-if="loading" class="text-center">Cargando datos...</p>
      <p v-if="error" class="text-danger text-center">{{ error }}</p>
  
      <TiempoCarrusel v-if="days.length" :days="days" />
    </div>
  </template>
  
  <script>
  import TiempoCarrusel from "../components/TiempoCarrusel.vue"
  
  export default {
    components: { TiempoCarrusel },
  
    data() {
      return {
        days: [],
        error: null,
        loading: true,
        apiUrl:
  "https://api.open-meteo.com/v1/forecast?latitude=41.62&longitude=0.62&models=best_match&daily=temperature_2m_max,temperature_2m_min,windspeed_10m_max&timezone=Europe%2FMadrid&past_days=3&forecast_days=15"
      }
    },
  
    mounted() {
      this.getWeather()
    },
  
    methods: {
      async getWeather() {
        try {
          const res = await fetch(this.apiUrl)
          if (!res.ok) throw new Error("No se pudo cargar la API")
  
          const data = await res.json()
  
          this.days = data.daily.time.map((t, i) => {
            const date = new Date(t)
            return {
              day: date.toLocaleDateString("es-ES", {
                weekday: "long",
                day: "numeric",
                month: "short"
              }),
              max: data.daily.temperature_2m_max[i],
              min: data.daily.temperature_2m_min[i],
              wind: data.daily.windspeed_10m_max[i]
            }
          })
  
        } catch (err) {
          this.error = err.message
        } finally {
          this.loading = false
        }
      }
    }
  }
  </script>
  