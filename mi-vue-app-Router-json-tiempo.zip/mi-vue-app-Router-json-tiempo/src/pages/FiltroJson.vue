<template>
    <div>
      <h1>Filtro: </h1>
      <p><strong></strong>Se usa un filtro para mostrar datos de un JSON en una lista</p>
      <p> Se usa grid y flex en el CSS (no se usa Bootstrap)</p>
      <p>Filtra por categoría:</p>
      <select v-model="filtro"> <!--- v-model une el select con la variable filtro -->
        <option value="">Todos</option>
        <option value="arte">Arte</option>
        <option value="diseño">Diseño</option>
        <option value="tecnología">Tecnología</option>
      </select>
  
      <ul>
        <li v-for="evento in eventosFiltrados" :key="evento.id"> <!--- usa la propiedad computada eventosFiltrados -->
          {{ evento.titulo }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  


  export default {
    // Estado del componente
    data() {
      return {
        eventos: [], // se crea el array donde se guardaran los evenos (obtenidos del json)
        filtro: '', // es la variable filtro que pemmite hacer el v-model en el select
        listaeventos: '/NetArt2526/json_eventos.json' // lugar donde estan los datos json guardados (en la carpeta public)
      }
    },
  
    // Lugar adecuado para cargar datos en Vue 3 (Options API)
    mounted() {
      fetch(this.listaeventos)   // 1. Pide el archivo 
        .then(res => res.json()) // 2. convierte la respuesta(res) en JSON
        .then(data => {
          this.eventos = data // 3. guarda los datos en el array eventos
        })
        .catch(err => {
          console.error('Error cargando json_eventos.json:', err) // 4. Manejo de errores
        })
    },
  
    // Propiedades calculadas
    computed: { 
      eventosFiltrados() { // devuelve los eventos filtrados según la categoría seleccionada
        if (!this.filtro) return this.eventos // si no hay filtro, devuelve todos los eventos
        return this.eventos.filter(e => e.categoria === this.filtro) // filtra los eventos por categoría
      }
    }
  }
  </script>
  
  <style scoped>
/* Contenedor elegante */
div {
  max-width: 80rem;
  margin: 2rem auto;
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.2rem;
  background: #f5f7fa;
  border-radius: 12px;
  border: 1px solid #e0e6ef;
}

/* Títulos */
h1 {
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 0.5rem;
}

/* Select moderno */
select {
  padding: 0.6rem 1rem;
  border-radius: 8px;
  border: 1px solid #ccd4df;
  font-size: 1rem;
  background: white;
  cursor: pointer;
  transition: all 0.2s ease;
}

select:hover {
  border-color: #7c8cff;
}

/* Lista → GRID cards */
ul {
  list-style: none;
  padding: 0;
  display: grid;
  gap: 0.8rem;

  /* Grid responsive */
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

/* Cada card */
li {
  background: white;
  padding: 1rem;
  border-radius: 10px;
  border: 1px solid #e0e6ef;
  box-shadow: 0 2px 4px rgba(0,0,0,0.04);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  font-size: 1.1rem;
  font-weight: 500;
}

/* Hover atractivo */
li:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 14px rgba(0,0,0,0.12);
}

/* Accesibilidad al foco */
li:focus,
select:focus {
  outline: 3px solid #7c8cff;
  outline-offset: 2px;
}
</style>
