<template>
  <H1> Terremotos Mundiales</H1>

    <!-- CONTROLES -->
    <div>
      <label class="form-label">Cantidad de terremotos</label>
      <select v-model="selectedLimit" @change="loadQuakes" class="form-select">
        <option v-for="opt in options" :key="opt.value" :value="opt.value">
          {{ opt.label }}
        </option>
      </select>
    </div>


    <div class="map-container">

    <!-- Mapa de fondo -->
    <img src="/worldmap.svg" class="world-map" alt="mapa del mundo"/>

    <!-- Puntos vibrantes -->
    <div 
      v-for="(e, i) in quakes"
      :key="i"
      class="quake-dot"
      :ref="el => quakeRefs[i] = el"
      :style="{
        top: e.screenY + 'px',
        left: e.screenX + 'px',
        backgroundColor: e.color,
        width: e.size + 'px',
        height: e.size + 'px'
      }"
      @mouseenter="showInfo(i)"
      @mouseleave="hideInfo"
    ></div>

    <!-- Panel de información -->
    <div v-if="activeQuake" class="info-panel">
      <h3>{{ activeQuake.place }}</h3>
      <p><strong>Magnitud:</strong> {{ activeQuake.mag }}</p>
      <p><strong>Profundidad:</strong> {{ activeQuake.depth }} km</p>
      <p><strong>Fecha:</strong> {{ activeQuake.date }}</p>
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { gsap } from 'gsap'

/* ----------------------------------------
   SELECTOR DE CANTIDAD DE TERREMOTOS
----------------------------------------- */
const selectedLimit = ref("20000")

const options = [
  { label: "50 terremotos (últimas horas)", value: "50" },
  { label: "5000 terremotos (últimos días)", value: "5000" },
  { label: "20000 terremotos (último mes)", value: "20000" }
]

/* ----------------------------------------
   VARIABLES REACTIVAS
----------------------------------------- */
const quakes = ref([])
const quakeRefs = ref([])
const activeQuake = ref(null)

/* ----------------------------------------
   FUNCIÓN DE CARGA
----------------------------------------- */
const loadQuakes = async () => {
  const limit = selectedLimit.value

  const url =
    `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&limit=${limit}`

  const res = await fetch(url)
  const data = await res.json()

  quakes.value = data.features.map(f => {
    const [lng, lat, depth] = f.geometry.coordinates
    const mag = f.properties.mag ?? 0

    // Convertimos coordenadas geográficas → coordenadas en pantalla
    const screenX = ((lng + 180) / 360) * window.innerWidth
    const screenY = ((90 - lat) / 180) * window.innerHeight

    return {
      mag,
      depth,
      place: f.properties.place,
      date: new Date(f.properties.time).toLocaleString(),
      screenX,
      screenY,
      size: 6 + mag * 3,
      color: depth < 50 ? "#ff433d" : depth < 150 ? "#ff883d" : "#3d9bff"
    }
  })

  animateDots()
}

/* ----------------------------------------
   ANIMACIÓN DEL PUNTO
----------------------------------------- */
const animateDots = () => {
  quakes.value.forEach((e, i) => {
    const el = quakeRefs.value[i]
    if (!el) return

    const intensity = e.mag * 2 + 2

    gsap.to(el, {
      x: `+=${intensity}`,
      y: `+=${intensity / 2}`,
      duration: 0.15 + Math.random() * 0.3,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    })
  })
}

/* ----------------------------------------
   INFO AL PASAR POR ENCIMA
----------------------------------------- */
const showInfo = (i) => {
  activeQuake.value = quakes.value[i]
}

const hideInfo = () => {
  activeQuake.value = null
}

/* ----------------------------------------
   CARGA INICIAL
----------------------------------------- */
onMounted(() => {
  loadQuakes()
})
</script>

<style scoped>
.map-container {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  position: relative;
  background: #000;
}

/* CONTROLES */
.controls {
  position: fixed;
  top: 20px;
  left: 20px;
  z-index: 10;
  width: 250px;
}

.world-map {
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.15;
  position: absolute;
  top: 0;
  left: 0;
}

/* PUNTOS */
.quake-dot {
  position: absolute;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  mix-blend-mode: screen;
  cursor: pointer;
  transition: transform 0.1s;
}

.quake-dot:hover {
  transform: translate(-50%, -50%) scale(1.3);
}

/* PANEL DE INFO */
.info-panel {
  position: fixed;
  bottom: 20px;
  left: 20px;
  background: rgba(0,0,0,0.85);
  padding: 1rem 1.5rem;
  border-radius: 8px;
  color: white;
  max-width: 320px;
  font-size: 0.95rem;
  z-index: 20;
}
</style>
