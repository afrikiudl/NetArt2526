<template>
  <div class="container py-4">

    <h1 class="text-center mb-4">Selector del tiempo por fecha</h1>
    <div class="alert alert-primary" role="alert">
        Este ejemplo muestra un selector que consulta en tiempo real los datos en el servidor.
      </div>

      <h2> El tiempo en Lleida</h2>
    <!-- SELECTOR DE FECHA -->
    <div class="row justify-content-center mb-4">
      <div class="col-md-4">
        <label class="form-label">Selecciona una fecha</label>
        <input type="date" class="form-control" v-model="selectedDate" />
      </div>

      <div class="col-md-2 d-flex align-items-end">
        <button class="btn btn-primary w-100" @click="consultar">
          Consultar
        </button>
      </div>
    </div>

    <p v-if="loading" class="text-center">Cargando...</p>
    <p v-if="error" class="text-danger text-center">{{ error }}</p>

    <!-- DÍA ACTUAL CONSULTADO -->
    <div class="d-flex justify-content-center mt-4" v-if="weather">
      <Tiempo1Dia
        :dayLabel="weather.dayLabel"
        :max="weather.max"
        :min="weather.min"
        :wind="weather.wind"
      />
    </div>

    <!-- LÍNEA DEL TIEMPO -->
    <div v-if="timeline.length" class="mt-5">
      <h3 class="text-center mb-3">Línea del tiempo</h3>
      <TiempoTimeline :list="timeline" />
    </div>

  </div>
</template>

<script>
import Tiempo1Dia from "../components/Tiempo1Dia.vue"
import TiempoTimeline from "../components/TiempoTimeline.vue"

export default {
  components: { Tiempo1Dia, TiempoTimeline },

  data() {
    return {
      selectedDate: null,
      weather: null,
      loading: false,
      error: null,
      timeline: []   // <-- Aquí guardamos todas las consultas
    }
  },

  methods: {
    async consultar() {
      if (!this.selectedDate) {
        this.error = "Selecciona una fecha válida"
        return
      }

      this.loading = true
      this.error = null
      this.weather = null

      const url = `https://api.open-meteo.com/v1/forecast?latitude=41.62&longitude=0.62&daily=temperature_2m_max,temperature_2m_min,windspeed_10m_max&timezone=Europe%2FMadrid&start_date=${this.selectedDate}&end_date=${this.selectedDate}`

      try {
        const res = await fetch(url)
        const data = await res.json()

        if (!data.daily.time.length) {
          throw new Error("No hay datos disponibles para esta fecha.")
        }

        const fecha = new Date(data.daily.time[0])

        const item = {
          dayLabel: fecha.toLocaleDateString("es-ES", {
            weekday: "long",
            day: "numeric",
            month: "long",
            year: "numeric"
          }),
          max: data.daily.temperature_2m_max[0],
          min: data.daily.temperature_2m_min[0],
          wind: data.daily.windspeed_10m_max[0]
        }

        // Mostrar en pantalla
        this.weather = item

        // Añadir a la línea del tiempo
        this.timeline.push(item)

      } catch (err) {
        this.error = err.message
      }

      this.loading = false
    }
  }
}
</script>
