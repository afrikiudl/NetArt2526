<template>
  <div class="container-lg py-5">
    
    <h1 class="display-5 fw-bold">a. Cards Originales, b. Cards con JSON propio, c.Cards con Glitch</h1>

    

    <p v-if="error" style="color:red; font-weight: bold;">
      Error cargando JSON: {{ error }}
    </p>

    <div class="alert alert-primary" role="alert">
      <h2>a. Cards Originales</h2>
        Solo cargan 4 Cards origijales, de ejemplo de bootstrap, fijas (sin json)
    </div>
    <div class="row g-4" >
    <CardOriginal/><CardOriginal/><CardOriginal/><CardOriginal/>
    </div>

    <div class="alert alert-primary" role="alert">
      <h2>b. Cards con JSON propio</h2>

         Cards segun la carga de un fichero JSON
    </div>

    
    <p v-if="proyectos.length === 0 && !error">Cargando proyectos...</p>


    <div class="row g-4" v-if="proyectos.length > 0">
      <div 
        class="col-12 col-sm-6 col-lg-4"
        v-for="p in proyectos" :key="p.id">
      
        <Card
          :id="p.id"
          :titulo="p.titulo"
          :texto="p.texto"
          :autor="p.autor"
          :srcimg="p.srcimg"
          :alt="p.alt"
          :url="p.url"
        />

        
      </div>
    </div>


    <div class="alert alert-primary" role="alert">

      <h2>c.Cards con Glitch</h2>
  Cards con efecto Glitch. Carga los mismos datos que antes.
</div>


    <div class="row g-4" v-if="proyectos.length > 0">
      <div 
        class="col-12 col-sm-6 col-lg-4"
        v-for="p in proyectos" :key="p.id">
      
        <CardGlitch
          :id="p.id"
          :titulo="p.titulo"
          :texto="p.texto"
          :autor="p.autor"
          :srcimg="p.srcimg"
          :alt="p.alt"
          :url="p.url"
        />

        
      </div>
    </div>


  </div>
</template>


<script>
import Card from '../components/Card.vue'
import CardOriginal from '../components/CardOriginal.vue'
import CardGlitch from '../components/CardGlitch.vue'

export default {
  components: { Card, CardOriginal,CardGlitch },

  data() {
    return {
      proyectos: [],
      listaproyectos: "NetArt2025/json_proyectos.json",
      error: null
    }
  },

  mounted() {
    fetch(this.listaproyectos)
      .then(res => {
        if (!res.ok) throw new Error("No se pudo cargar el JSON");
        return res.json();
      })
      .then(data => {
        this.proyectos = data;
      })
      .catch(err => {
        this.error = err.message;
        console.error(err);
      });
  }
}
</script>
