<template>
  <div class="home-container">

    <!-- HERO -->
    <section class="hero" ref="heroRef">
      <h1 class="title">Atlas de Datos Vivos</h1>
      <p class="subtitle">
        Obras digitales basadas en datos reales. <br/>
         El planeta, el clima y el tiempo convertidos en Net Art.
      </p>
    
    </section>

    <!-- BLOQUES 1–3 EN FILA -->
    <div class="full-sections-row">

      <!-- BLOQUE 1 -->
      <section class="full-section" ref="block1">
        <div class="project-card big">
          <div class="icon">🌋</div>
          <h2>El Planeta Vibra</h2>
          <p class="desc">
            Un mapa artístico donde cada terremoto real se transforma en una vibración, un pulso, 
            un latido del planeta. Los datos geológicos se vuelven experiencia.
          </p>
          <router-link to="/earthquake" class="btn">Ver mapa vibrante →</router-link>
        </div>
      </section>

      <!-- BLOQUE 2 -->
      <section class="full-section" ref="block2">
        <div class="project-card big">
          <div class="icon">🌤️</div>
          <h2>Clima en Movimiento</h2>
          <p class="desc">
            El clima se convierte en un organismo visual. La temperatura, el viento y las fechas 
            generan colores, vibración y atmósferas digitales.
          </p>
          <router-link to="/listatiempo" class="btn">Ver proyecto de clima →</router-link>
        </div>
      </section>

      <!-- BLOQUE 3 -->
      <section class="full-section" ref="block3">
        <div class="project-card big">
          <div class="icon">📅</div>
          <h2>Tiempo por Fecha</h2>
          <p class="desc">
            Selecciona un día concreto y observa cómo sus datos meteorológicos se transforman 
            en una pieza visual generativa.
          </p>
          <router-link to="/tiemposelector" class="btn">Ver selector →</router-link>
        </div>
      </section>

    </div>


    <!-- BLOQUE 4 (CARDS Y EVENTOS) -->
     <!--
    <section class="half-section" ref="block4">
      <div class="project-card">
        <div class="icon small-icon">🗂️</div>
        <h3>Cards desde JSON</h3>
        <p>Carga de datos y representación visual de tarjetas dinámicas.</p>
        <router-link to="/listacards" class="btn small">Ver cards →</router-link>
      </div>

      <div class="project-card" ref="block5">
        <div class="icon small-icon">🔍</div>
        <h3>Filtrar Eventos</h3>
        <p>JSON dinámico con opciones de filtrado y búsqueda.</p>
        <router-link to="/eventos" class="btn small">Filtrar eventos →</router-link>
      </div>
    </section>
  -->

  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

// refs
const heroRef = ref(null);
const block1 = ref(null);
const block2 = ref(null);
const block3 = ref(null);
const block4 = ref(null);
const block5 = ref(null);

onMounted(() => {
  /* HERO */
  gsap.from(heroRef.value, {
    opacity: 0,
    y: -50,
    duration: 1.2,
    ease: "power3.out",
  });

  gsap.to(heroRef.value, {
    y: 80,
    scrollTrigger: {
      trigger: heroRef.value,
      start: "top top",
      end: "bottom top",
      scrub: true,
    },
  });

  /* BLOQUES FULL SCREEN */
  const fullBlocks = [block1.value, block2.value, block3.value];

  fullBlocks.forEach((b) => {
    gsap.from(b, {
      opacity: 0,
      y: 100,
      duration: 1.2,
      ease: "power3.out",
      scrollTrigger: {
        trigger: b,
        start: "top 85%",
      },
    });
  });

  /* BLOQUE 4 (2 cards) */
  gsap.from(block4.value, {
    opacity: 0,
    y: 100,
    duration: 1.2,
    ease: "power3.out",
    scrollTrigger: {
      trigger: block4.value,
      start: "top 85%",
    },
  });
});
</script>

<style scoped>
.home-container {
  width: 100%;
  min-height: 100vh;
  background: #0a0a0a;
  color: white;
  font-family: "Inter", sans-serif;
  overflow-x: hidden;
}

/* HERO */
.hero {
  text-align: center;
  padding: 14vh 2rem;
}

.title {
  font-size: clamp(3.5rem, 10vw, 8rem);
  font-weight: 900;
  margin-bottom: 1rem;
}

.subtitle {
  opacity: 0.85;
  font-size: clamp(1.4rem, 2.5vw, 2rem);
  max-width: 700px;
  margin: auto;
  line-height: 1.5;
}

.scroll-hint {
  margin-top: 3rem;
  font-size: 1.3rem;
  opacity: 0.6;
}

/* FILA HORIZONTAL PARA BLOQUES 1–3 */
.full-sections-row {
  display: flex;
  gap: 3rem;
  padding: 4rem 2rem;
  justify-content: center;
}

.full-sections-row .full-section {
  height: auto;
  flex: 1;
}

@media (max-width: 1000px) {
  .full-sections-row {
    flex-direction: column;
  }
}

/* FULL SECTIONS */
.full-section {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 2rem;
}

/* HALF SECTION */
.half-section {
  padding: 5rem 2rem;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
}

@media (max-width: 900px) {
  .half-section {
    grid-template-columns: 1fr;
  }
}

/* CARDS */
.project-card {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 16px;
  padding: 2.8rem;
  text-align: center;
  backdrop-filter: blur(8px);
  transition: transform 0.3s ease;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.5);
}

.project-card.big {
  max-width: 600px;
}

/* ICONOS GRANDES (autores) */
.icon {
  font-size: 10rem;
  line-height: 1;
  margin-bottom: 1.5rem;
  text-shadow: 0 0 25px rgba(255, 255, 255, 0.25);
  filter: drop-shadow(0 4px 20px rgba(0, 0, 0, 0.45));
}

/* Iconos más pequeños (cards inferiores) */
.small-icon {
  font-size: 4.5rem !important;
}

/* TEXTOS */
h2 {
  font-size: clamp(2.6rem, 6vw, 3.6rem);
  margin-bottom: 1rem;
  font-weight: 800;
}

h3 {
  font-size: 2.4rem;
  font-weight: 700;
}

.desc,
.project-card p {
  font-size: clamp(1.3rem, 2.2vw, 1.7rem);
  opacity: 0.9;
  line-height: 1.55;
  margin-bottom: 2.2rem;
}

/* BOTONES */
.btn {
  display: inline-block;
  color: white;
  border-bottom: 3px solid white;
  text-decoration: none;
  padding-bottom: 4px;
  font-size: 1.6rem;
  font-weight: 600;
}

.btn.small {
  font-size: 1.3rem;
}
</style>
