<template>
    <nav>
      <router-link to="/">Inicio</router-link>
      <router-link to="/earthquakemap">Terremotos </router-link>
      <router-link to="/listatiempo">Tiempo</router-link>
      <router-link to="/tiemposelector">Selector del Tiempo </router-link>
      <!--<router-link to="/filtrojson">Filtro Json</router-link>
      <router-link to="/listacards">Listacards</router-link>
-->
      
    </nav>
  </template>
  
  <script>
  export default {
    name: "Menu"
  }
  </script>
  
  <style scoped>
  nav {
    background: #9942b8;
    padding: 1rem;
    display: flex;
    gap: 1.5rem;
  }
  
  nav a {
    color: white;
    text-decoration: none;
    font-weight: 500;
  }
  
  nav a.router-link-exact-active {
    font-weight: bold;
    text-decoration: underline;
  }
  </style>
  