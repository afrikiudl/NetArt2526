<template>
  <ul class="timeline-container">

    <li
      v-for="(item, i) in list"
      :key="i"
      class="timeline-item"
      ref="items"
    >
      <Tiempo1Dia
        :dayLabel="item.dayLabel"
        :max="item.max"
        :min="item.min"
        :wind="item.wind"
      />
    </li>

  </ul>
</template>

<script>
import { gsap } from "gsap"
import Tiempo1Dia from "../Nueva/Tiempo1Dia.vue"

export default {
  name: "TiempoTimeline",
  components: { Tiempo1Dia },

  props: {
    list: {
      type: Array,
      required: true
    }
  },

  mounted() {
    const items = this.$refs.items

    gsap.from(items, {
      opacity: 0,
      y: 30,
      duration: 0.6,
      stagger: 0.15,
      ease: "power2.out"
    })
  }
}
</script>

<style scoped>
/* LISTA HORIZONTAL */
.timeline-container {
  display: flex;
  flex-direction: row;
  gap: 1.5rem;
  padding: 0;
  margin-top: 2rem;
  list-style: none;
  overflow-x: auto;   /* permite scroll si hay muchas */
  padding-bottom: 1rem;
}

/* Cada tarjeta de Tiempo1Dia */
.timeline-item {
  min-width: 200px;    /* ajusta según quieras */
  display: flex;
}
</style>
