<template>
    <div>
      <div class="card mb-3" style="max-width: 20rem;">
        <img :src="srcimg" :alt="alt" class="card-img-top">
  
        <div class="card-body">
          <h5 class="card-title">{{ titulo }}</h5>
          <p class="card-text">{{ texto }}</p>
  
          <a
            :href="url"
            class="btn btn-primary"
            title="Ir a la página del proyecto"
          >
            Ir al proyecto
          </a>
        </div>
  
        <div class="card-footer text-muted">
          {{ autor }}
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    props: ["id", "autor", "titulo", "srcimg", "alt", "texto", "url"]
  }
  </script>
  
  <style scoped></style>
  