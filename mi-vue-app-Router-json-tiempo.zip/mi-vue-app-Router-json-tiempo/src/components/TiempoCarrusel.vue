<template>
  <div class="container py-4">
    <h2 class="fw-bold text-center mb-3">Pronóstico (El tiempo en Lleida)</h2>

    <div class="lista-grid">
      <Tiempo1Dia
        v-for="(d, i) in days"
        :key="i"
        class="item"
        :dayLabel="d.day"
        :max="d.max"
        :min="d.min"
        :wind="d.wind"
      />
    </div>

  </div>
</template>

<script>
import Tiempo1Dia from "./Tiempo1Dia.vue"

export default {
  name: "TiempoCarrusel",
  components: { Tiempo1Dia },
  props: { days: Array }
}
</script>

<style scoped>
/* 🌟 Grid responsivo */
.lista-grid {
  display: grid;
  gap: 1.5rem;
  padding: 1rem 0;

  /* Grid dinámico */
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  justify-items: center;
}

/* Cada tarjeta */
.item {
  width: 100%;
  max-width: 260px;
}

/* FALLBACK AUTOMÁTICO: si un navegador no soporta grid → usa flex */
@supports not (display: grid) {
  .lista-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
}
</style>
