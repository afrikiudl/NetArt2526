<template>
  <div
    class="tiempo-card"
    ref="card"
    :style="{ backgroundColor: bgColor, borderColor: borderColor }"
  >
    <!-- ICONO -->
    <div class="weather-icon-wrapper">
      <i :class="['weather-icon', iconClass]"></i>
    </div>

    <!-- CONTENIDO -->
    <div class="content">
      <h4 class="title">{{ dayLabel }}</h4>

      <p class="info">
        🌡️ Máx: <strong>{{ max }}°C</strong> · Mín: <strong>{{ min }}°C</strong>
      </p>

      <p class="info">
        💨 Viento: <strong>{{ wind }} km/h</strong>
      </p>
    </div>
  </div>
</template>

<script>
import { gsap } from "gsap"

export default {
  name: "Tiempo1Dia",

  props: {
    dayLabel: String,
    max: Number,
    min: Number,
    wind: Number
  },

  computed: {
    /*----------------------------------------
      COLOR SEGÚN TEMPERATURA (sin degradado)
    ----------------------------------------*/
    bgColor() {
      const media = (this.max + this.min) / 2

      const cold = [80, 150, 255]
      const hot = [255, 130, 90]

      const ratio = Math.min(1, Math.max(0, (media + 5) / 35))
      const mix = (a, b) => Math.round(a + (b - a) * ratio)

      const r = mix(cold[0], hot[0])
      const g = mix(cold[1], hot[1])
      const b = mix(cold[2], hot[2])

      return `rgb(${r}, ${g}, ${b})`
    },

    borderColor() {
      const media = (this.max + this.min) / 2
      return media < 10 ? "#3b5fa8" : "#a8463b"
    },

    /*----------------------------------------
      ICONO SEGÚN CLIMA
    ----------------------------------------*/
    iconClass() {
      const media = (this.max + this.min) / 2
      if (this.wind > 40) return "bi-wind"
      if (media <= 2) return "bi-snow2"
      if (media < 10) return "bi-cloud-snow"
      if (media < 18) return "bi-cloud"
      return "bi-sun-fill"
    },

    /*----------------------------------------
      MOVIMIENTO SEGÚN VIENTO
    ----------------------------------------*/
    windMovement() {
      if (!this.wind || this.wind === 0) return 0

      // Escala progresiva perceptible
      if (this.wind < 10) return 5       // leve
      if (this.wind < 20) return 12      // suave
      if (this.wind < 30) return 22      // moderado
      if (this.wind < 40) return 32      // fuerte
      if (this.wind < 60) return 50      // muy fuerte
      return 75                           // extremo
    }
  },

  mounted() {
    const el = this.$refs.card

    /*----------------------------------------
      APARICIÓN
    ----------------------------------------*/
    gsap.from(el, {
      opacity: 0,
      y: 15,
      duration: 0.7,
      ease: "power2.out"
    })

    /*----------------------------------------
      MOVIMIENTO POR VIENTO
    ----------------------------------------*/
    if (this.windMovement > 0) {
      gsap.to(el, {
        x: this.windMovement,
        y: this.windMovement / 4,
        rotate: this.windMovement / 25,
        repeat: -1,
        yoyo: true,
        duration: 1.8,
        ease: "sine.inOut"
      })
    }

    /*----------------------------------------
      ICONO VIBRA SUTILMENTE
    ----------------------------------------*/
    const icon = el.querySelector(".weather-icon")

    if (this.windMovement > 0) {
      gsap.to(icon, {
        x: this.windMovement / 10,
        yoyo: true,
        repeat: -1,
        duration: 0.35,
        ease: "sine.inOut"
      })
    }
  }
}
</script>

<style scoped>
/*----------------------------------------
  CARD INSPIRADA EN BOOTSTRAP
----------------------------------------*/
.tiempo-card {
  width: 260px;
  border-radius: 16px;
  border: 2px solid;
  padding: 1.3rem;
  background: white;
  color: #111;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.4rem;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
  position: relative;
  overflow: hidden;
  transition: transform 0.2s ease;
}

.tiempo-card:hover {
  transform: scale(1.03);
}

/* ICONO */
.weather-icon {
  font-size: 3.3rem;
  color: #000;
}

.weather-icon-wrapper {
  display: flex;
  justify-content: center;
  margin-bottom: 0.4rem;
}

/* TEXTOS */
.title {
  font-weight: 800;
  margin-bottom: 0.3rem;
  text-transform: capitalize;
}

.info {
  margin: 0;
  font-size: 0.95rem;
}
</style>
