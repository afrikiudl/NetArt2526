<template>
  <div class="mi-card" ref="card">

    <div class="glitch-container card-img-overlay">

      <!-- Imagen original -->
      <img :src="srcimg" :alt="alt" class="glitch-img base-img" />

      <!-- Canales RGB duplicados -->
      <img :src="srcimg" class="glitch-img r" />
      <img :src="srcimg" class="glitch-img g" />
      <img :src="srcimg" class="glitch-img b" />

      <!-- Líneas verticales -->
      <div class="scanlines"></div>

      <!-- Pixel blocks -->
      <div class="pixel-blocks" ref="pixels"></div>
    </div>

    <h3 class="titulo">{{ titulo }}</h3>
    <p class="texto">{{ texto }}</p>
    <a :href="url" class="btn-card" target="_blank">Ver proyecto</a>

  </div>
</template>

<script>
import { gsap } from "gsap"

export default {
  props: ["id", "autor", "titulo", "srcimg", "alt", "texto", "url"],

  mounted() {
    /* ----------------------------------
       EFECTO RGB CONTINUO Y PERMANENTE
    ------------------------------------- */
    gsap.to(this.$el.querySelector(".r"), {
      x: 3,
      yoyo: true,
      repeat: -1,
      duration: 0.4,
      ease: "sine.inOut"
    });

    gsap.to(this.$el.querySelector(".g"), {
      x: -3,
      yoyo: true,
      repeat: -1,
      duration: 0.5,
      ease: "sine.inOut"
    });

    gsap.to(this.$el.querySelector(".b"), {
      x: 2,
      yoyo: true,
      repeat: -1,
      duration: 0.35,
      ease: "sine.inOut"
    });

    /* ----------------------------------
       LÍNEAS VERTICALES ANIMADAS
    ------------------------------------- */
    gsap.to(this.$el.querySelector(".scanlines"), {
      opacity: 0.4,
      duration: 1.5,
      repeat: -1,
      yoyo: true,
      ease: "sine.inOut"
    });

    /* ----------------------------------
       PIXEL BLOCKS (tele de mala señal)
    ------------------------------------- */
    const pixels = this.$refs.pixels;

    gsap.to(pixels, {
      clipPath: () => {
        const y = Math.random() * 70;
        const h = 10 + Math.random() * 40;
        return `inset(${y}% 0% ${100 - (y + h)}% 0%)`;
      },
      x: () => (Math.random() - 0.5) * 60,
      opacity: 0.5,
      duration: 0.6,
      repeat: -1,
      ease: "steps(2)"
    });
  }
}
</script>

<style scoped>
.mi-card {
  border: 2px solid #ccc;
  border-radius: 12px;
  padding: 1rem;
  background: white;
  text-align: center;
  overflow: hidden;
}

/* CONTENEDOR GLITCH */
.glitch-container {
  position: relative;
  width: 100%;
  height: 200px;
  overflow: hidden;
  border-radius: 10px;
}

/* IMÁGENES RGB */
.glitch-img {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.base-img { 
  z-index: 1; 
}

.r { 
  mix-blend-mode: screen;
  filter: hue-rotate(10deg) saturate(2);
  opacity: 0.6;
  z-index: 2;
}

.g { 
  mix-blend-mode: screen;
  filter: hue-rotate(120deg) saturate(1.5);
  opacity: 0.6;
  z-index: 3;
}

.b { 
  mix-blend-mode: screen;
  filter: hue-rotate(240deg) saturate(2);
  opacity: 0.6;
  z-index: 4;
}

/* LÍNEAS VERTICALES (scanlines) */
.scanlines {
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    90deg,
    rgba(255,255,255,0.05) 0px,
    rgba(255,255,255,0.05) 2px,
    transparent 3px,
    transparent 8px
  );
  opacity: 0.3;
  z-index: 5;
  pointer-events: none;
}

/* PIXEL BLOCKS */
.pixel-blocks {
  position: absolute;
  inset: 0;
  background: inherit;
  background-size: cover;
  mix-blend-mode: difference;
  z-index: 6;
  opacity: 0.4;
}

/* TEXTO */
.titulo {
  margin-top: 1rem;
  font-weight: bold;
}
.texto {
  opacity: 0.9;
}

.btn-card {
  display: inline-block;
  margin-top: 0.6rem;
  padding: 0.4rem 1rem;
  background: #007bff;
  color: white;
  border-radius: 6px;
  text-decoration: none;
}
</style>
