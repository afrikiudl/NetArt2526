
import { createRouter, createWebHistory } from 'vue-router'
import Home from '../pages/Home.vue'
import ListaTiempo from '../pages/ListaTiempo.vue'
import ListaCards from '../pages/ListaCards.vue'
import TiempoSelector from '../pages/TiempoSelector.vue'
import EarthquakeMap from '../pages/EarthquakeMap.vue'
import FiltroJson from '../pages/FiltroJson.vue'




const routes = [
{ path: '/', component: Home },
{ path: '/listatiempo', component: ListaTiempo },
{ path: '/listacards', component: ListaCards },
{ path: '/tiemposelector', component: TiempoSelector },
{ path: '/earthquakemap', component: EarthquakeMap },
{ path: '/filtrojson', component: FiltroJson }

]


const router = createRouter({
history: createWebHistory(),
routes
})


export default router
